package com.app.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
