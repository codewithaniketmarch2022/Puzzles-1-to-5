package com.app.employee.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


import com.app.employee.entities.Credentials;
import com.app.employee.entities.Employee;
import com.app.employee.entities.Response;
import com.app.employee.services.EmployeeServiceImpl;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/user/")
public class EmployeeController {
	@Autowired
	private EmployeeServiceImpl userService;

	@Autowired
	private Employee userDao;

	@Autowired
	

	@PostMapping("/signin")
	public ResponseEntity<?> signIn( @RequestBody Credentials cred) {
		Employee user = userService.findUserByUsernameAndPassword(cred);
		if (user == null)
			return Response.error("user not found");
		
		int userId=user.getId();
		
		return Response.success(user);
	}

	@PostMapping("/signup")
	public ResponseEntity<?> signUp(@RequestBody Employee user) {
		
		try {
			Credentials cred = new Credentials();
			cred.setUsername(user.getEmail());
			cred.setPassword(user.getPassword());

			Employee users = userService.findUserByUsernameAndPassword(cred);

			Employee result = userService.saveUser(user);
			
			System.out.println(result.getPassword());
			
			return Response.success(result);
			
		} catch (Exception e) {

			return Response.error("Enter valid  username or username already registered");
		}

	}

	
	@GetMapping("/search")
	public ResponseEntity<?> findUser() {
		List<Employee> result = new ArrayList<>();
		result = userService.findAllUsers();
		return Response.success(result);
	}




}

	
	
	
	
