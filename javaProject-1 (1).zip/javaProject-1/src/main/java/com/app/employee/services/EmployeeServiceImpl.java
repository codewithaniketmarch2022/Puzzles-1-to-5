package com.app.employee.services;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;


import com.app.employee.daos.EmpployeeDao;
import com.app.employee.entities.*;



@Service
public class EmployeeServiceImpl {
	@Autowired
	private EmpployeeDao userDao;



	
	public Employee findUserFromdbByEmail(String username) {
		Employee user = userDao.findByEmail(username);
		return user;
	}

	public Employee findUserFromdbById(int userId) {
		Employee user = userDao.findById(userId);
		return user;
	}

	

	public Employee findUserByUsernameAndPassword(Credentials cred) {
		Employee user = userDao.findByEmail(cred.getUsername());
		String rawPassword = cred.getPassword();
		if (user != null && rawPassword==user.getPassword()) {
			
			return user;
		}
		return null;
	}
	
	public List<Employee> findAllUsers(){
		List<Employee> userList= userDao.findAll();
		return userList;
	}
	
	
	
	public Employee saveUser(Employee user) {
		
		Employee newUser = findUserFromdbByEmail(user.getEmail());
		if (newUser != null) {		
				return null;
		}

		String rawPassword = user.getPassword();

		user.setPassword(rawPassword);
		
		
		
			user = userDao.save(user);
			
			return user;

	}
	
	
	
	public int delete(int id) {
		userDao.deleteById(id);
		return 1;	
	}
}
